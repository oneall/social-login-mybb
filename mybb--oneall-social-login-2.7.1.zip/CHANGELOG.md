# Change Log

All notable changes to this project will be documented in this file. This project adheres to [Semantic Versioning](http://semver.org/).

## [2.7.1] - 2019-07-01
- Better error message if registration fails
- Skip validation for custom profile fields

## [2.7.0] - 2017-10-31
- Provider Tumblr added